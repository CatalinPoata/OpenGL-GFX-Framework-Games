#ifndef _HELPERS_H
#define _HELPERS_H 1

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string>
#include <cstdlib>
#include <netinet/tcp.h>
#include "helpers.h"
#include <string>
#include <vector>
#include <map>
#include <cmath>

#pragma pack(1)

using namespace std;

/*
 * Macro de verificare a erorilor
 * Exemplu:
 *     int fd = open(file_name, O_RDONLY);
 *     DIE(fd == -1, "open failed");
 */

#define DIE(assertion, call_description)	\
	do {									\
		if (assertion) {					\
			fprintf(stderr, "(%s, %d): ",	\
					__FILE__, __LINE__);	\
			perror(call_description);		\
			exit(EXIT_FAILURE);				\
		}									\
	} while(0)

#define BUFLEN		1600	// dimensiunea maxima a calupului de date
#define MAX_CLIENTS	100	// numarul maxim de clienti in asteptare
#define CHUNKLEN 256 // dimensiunea maxima a unui chunk
#define TOPICLEN 50 // dimensiunea maxima a campului "Topic"
#define TYPEIND 50 // indexul tipului de mesaj
#define CONTIND 51 // indexul continutului
#define TYPELEN 1 // dimensiunea campului type
#define CONTENTLEN 1500 // dimensiunea maxima pentru continut

typedef struct udp_msg{
    char topic[50];
    char type;
    char content[1500];
} udp_msg;

typedef struct sent_udp{
    in_addr ip;
    unsigned short port;
    udp_msg message;
}sent_udp;

typedef struct topic{
    int SF;
    vector<sent_udp> notifications;
}topic;

typedef struct int_msg{
    char sgn;
    uint32_t number;
}int_msg;

typedef struct short_real_msg{
    uint16_t number;
}short_real_msg;

typedef struct float_msg{
    char sgn;
    uint32_t significand;
    uint8_t exponent;
}float_msg;


typedef struct client{
    string IP;
    uint32_t port;
    bool online;
    map<string, topic> topics;
} client;

client newClient(char* ip, uint32_t port){
    client* newclient = (client*)calloc(1, sizeof(client));
    newclient->IP = ip;
    newclient->port = port;
    return *newclient;
}

topic newTopic(int SF){
    topic* newtopic = (topic*)calloc(1, sizeof(topic));
    newtopic->SF = SF;
    return *newtopic;
}


int send_message(int sockfd, char* data, uint32_t size){
    int i = 0;
    int ret;
    uint32_t conv = htonl(size);
    
    //trimite dimensiunea mesajului receiver-ului
    ret = send(sockfd, (char*)&conv, sizeof(uint32_t) , 0);

    if(ret < 0){
        return -1;
    }

    //sparge mesajul in bucati si trimite-l pe bucati
    while(i+CHUNKLEN < size){
        ret = send(sockfd, (data+i), CHUNKLEN, 0);
        if(ret < 0){
            return -1;
        }
        i+=CHUNKLEN;
    }

    //trimite si restul, daca a mai ramas o bucata care sa nu fie de 16 bytes
    if(i < size){
        ret = send(sockfd, (data+i), (size-i), 0);
        if(ret < 0){
            return -1;
        }
    }
    //returneaza dimensiunea mesajului trimis
    return size;
}

int recv_message(int sockfd, char* msg){
    uint32_t size;
    int i = 0;

    //primeste marimea mesajului
    int ret = recv(sockfd, (char*)&size, sizeof(uint32_t), MSG_WAITALL);
    
    //daca mesajul e gol => clientul s-a deconectat
    if(ret == 0){
        return 0;
    }

    if(ret <= 0){
        return -1;
    }

    size = ntohl(size);

    //Citeste mesajul pe bucati si concateneaza-l la rezultat
    while(i+CHUNKLEN < size){
        ret = recv(sockfd, (msg+i), CHUNKLEN, 0);
        if(ret <= 0){
            return -1;
        }
        i += CHUNKLEN;
    }

    //Adauga si restul, daca exista
    if(i < size){
        ret = recv(sockfd, (msg+i), size-i, 0);
        if(ret <= 0){
            return -1;
        }
    }

    //Returneaza lungimea mesajului citit
    return strlen(msg);
}

void processUDP(map<string, client> &users, map<string, int> &idtofd, char* data, struct sockaddr_in cli_addr){
    udp_msg *message;
	message = (udp_msg*)data;
    int ret;

    sent_udp toSend;
    toSend.ip = cli_addr.sin_addr;
    toSend.port = cli_addr.sin_port;
    toSend.message = *message;

   for(map<string, client>::iterator it = users.begin(); it != users.end(); it++){
        if(it->second.topics.count(message->topic) > 0 && it->second.online){
            ret = send_message(idtofd[it->first], (char*)&toSend, sizeof(sent_udp));
            DIE(ret < 0, "send");
        }else if(it->second.topics.count(message->topic) > 0 && (!it->second.online) && it->second.topics[message->topic].SF == 1){
            sent_udp *permToSend = (sent_udp*)calloc(1, sizeof(sent_udp));
            memset(permToSend, 0, sizeof(sent_udp));
            memcpy(permToSend, &toSend, sizeof(sent_udp));
            it->second.topics[message->topic].notifications.push_back(*permToSend);
        }
	}
}

void updateClient(map<string, client> &users, map<string, int> idtofd, char* id, char* ip, uint32_t port){
    users[id].IP = ip;
    users[id].port = port;
    users[id].online = true;
}

void printData(sent_udp data){
    map<int, string> types { {0, "INT"}, {1, "SHORT_REAL"}, {2, "FLOAT"}, {3, "STRING"}};
    
    
    /* Decomentati asta pt versiunea ca in enunt.
    switch(data.message.type){
        case 0: {
            int_msg *msg = (int_msg*)data.message.content;
            if(msg->sgn == 1){
                printf("%s:%d - %s - %s - %d\n", inet_ntoa(data.ip), data.port, data.message.topic, types[data.message.type].c_str(), -1 * msg->number);
            }else{
                printf("%s:%d - %s - %s - %d\n", inet_ntoa(data.ip), data.port, data.message.topic, types[data.message.type].c_str(), msg->number);
            }
            break;
        }
        case 1: {
            short_real_msg *msg = (short_real_msg*)data.message.content;
            if(msg->number/100 == msg->number*1.0/100){
                printf("%s:%d - %s - %s - %d\n", inet_ntoa(data.ip), data.port, data.message.topic, types[data.message.type].c_str(), msg->number/100);
            }else{
                printf("%s:%d - %s - %s - %.2f\n", inet_ntoa(data.ip), data.port, data.message.topic, types[data.message.type].c_str(), msg->number*1.0/100);
            }
            break;
        }
        case 2: {
            float_msg *msg = (float_msg*)data.message.content;
            if(msg->sgn == 1){
                printf("%s:%d - %s - %s - %.*f\n", inet_ntoa(data.ip), data.port, data.message.topic, types[data.message.type].c_str(), msg->exponent, msg->significand*(-1.0)/pow(10, msg->exponent));
            }else{
                printf("%s:%d - %s - %s - %.*f\n", inet_ntoa(data.ip), data.port, data.message.topic, types[data.message.type].c_str(), msg->exponent, msg->significand*1.0/pow(10, msg->exponent));
            }
            break;
        }
        case 3: {
            printf("%s:%d - %s - %s - %s\n", inet_ntoa(data.ip), data.port, data.message.topic, types[data.message.type].c_str(), data.message.content);
            break;
        }
        default: {
            break;
        }
    }
    */

   //Stergeti asta daca vreti versiunea ca in enunt, nu cea verificata de checker
   switch(data.message.type){
        case 0: {
            int_msg *msg = (int_msg*)data.message.content;
            if(msg->sgn == 1){
                printf("%s - %s - %d\n", data.message.topic, types[data.message.type].c_str(), -1 * ntohl(msg->number));
            }else{
                printf("%s - %s - %d\n", data.message.topic, types[data.message.type].c_str(), ntohl(msg->number));
            }
            break;
        }
        case 1: {
            short_real_msg *msg = (short_real_msg*)data.message.content;
            if(msg->number/100 == msg->number*1.0/100){
                printf("%s - %s - %d\n", data.message.topic, types[data.message.type].c_str(), ntohs(msg->number)/100);
            }else{
                printf("%s - %s - %.2f\n", data.message.topic, types[data.message.type].c_str(), ntohs(msg->number)*1.0/100);
            }
            break;
        }
        case 2: {
            float_msg *msg = (float_msg*)data.message.content;

            if(msg->sgn == 1){
                printf("%s - %s - %.*f\n", data.message.topic, types[data.message.type].c_str(), msg->exponent, ntohl(msg->significand) * (-1.0) / pow(10, msg->exponent));
            }else{
                printf("%s - %s - %.*f\n", data.message.topic, types[data.message.type].c_str(), msg->exponent, ntohl(msg->significand)*1.0/pow(10, msg->exponent));
            }
            break;
        }
        case 3: {
            printf("%s - %s - %s\n", data.message.topic, types[data.message.type].c_str(), data.message.content);
            break;
        }
        default: {
            break;
        }
    }
}

#endif